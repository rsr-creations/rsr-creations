export default function Navbar() {
  return (
    <nav className="w-screen h-0 bg-transparent text-light/20 font-mono text-center flex flex-col font-bold justify-center relative top-8"></nav>
  );
}
